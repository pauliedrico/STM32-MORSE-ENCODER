/*
 * morse.h
 *
 *  Created on: 14 nov 2022
 *      Author: Mario Porcaro
 */

#ifndef MORSE_H_
#define MORSE_H_

/*
The function charToMorse(char buff[],char ch) converts input character ch into a morse code string,
then saves it into buff[].
Parameters:
- the char we want to translate in morse (only  uppercase A-Z letters and 0-9 numbers)
- the buffer where we want to save the morse string
*/
void charToMorse(char buff[],char ch);

#endif /* MORSE_H_ */
