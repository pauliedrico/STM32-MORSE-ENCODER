/*
 * morse.c
 *
 *  Created on: 15 nov 2022
 *      Author: Mario Porcaro
 */
#include "morse.h"
#include <stdio.h>

void charToMorse(char buff[],char ch){
  switch(ch){
      case 'A': sprintf(buff,".- ");return;
      case 'B': sprintf(buff,"-... ");return;
      case 'C': sprintf(buff,"-.-. ");return;
      case 'D': sprintf(buff,"-.. ");return;
      case 'E': sprintf(buff,". ");return;
      case 'F': sprintf(buff,"..-. ");return;
      case 'G': sprintf(buff, "--. ");return;
      case 'H': sprintf(buff,".... ");return;
      case 'I': sprintf(buff,".. ");return;
      case 'L': sprintf(buff,".-.. ");return;
      case 'M': sprintf(buff,"-- ");return;
      case 'N': sprintf(buff,"-. ");return;
      case 'O': sprintf(buff,"--- ");return;
      case 'P': sprintf(buff,".--. ");return;
      case 'Q': sprintf(buff,"--.- ");return;
      case 'R': sprintf(buff,".-. ");return;
      case 'S': sprintf(buff,"... ");return;
      case 'T': sprintf(buff,"- ");return;
      case 'U': sprintf(buff,"..- ");return;
      case 'V': sprintf(buff,"...- ");return;
      case 'Z': sprintf(buff,"--.. ");return;
      case 'X': sprintf(buff,"-..- ");return;
      case 'Y': sprintf(buff,"-.-- ");return;
      case 'J': sprintf(buff,".--- ");return;
      case 'K': sprintf(buff,"-.- ");return;
      case 'W': sprintf(buff,".-- ");return;
      case '1': sprintf(buff,".---- ");return;
      case '2': sprintf(buff,"..--- ");return;
      case '3': sprintf(buff,"...-- ");return;
      case '4': sprintf(buff,"....- ");return;
      case '5': sprintf(buff,"..... ");return;
      case '6': sprintf(buff,"-.... ");return;
      case '7': sprintf(buff,"--... ");return;
      case '8': sprintf(buff,"---.. ");return;
      case '9': sprintf(buff,"----. ");return;
      case '0': sprintf(buff,"----- ");return;
      case ' ': sprintf(buff,"/ ");return;
      case '\n': sprintf(buff,"\n ");return;
      default : sprintf(buff," ");return;
      }
}

